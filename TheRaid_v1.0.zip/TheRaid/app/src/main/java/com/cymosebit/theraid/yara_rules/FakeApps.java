package com.cymosebit.theraid.yara_rules;

import java.util.Locale;

/**
 * Created by theraid on 11/16/17.
 * Source: https://github.com/Yara-Rules/rules/blob/master/Mobile_Malware/Android_FakeApps.yar
 */

public class FakeApps {
    // Facebook variables
    private final String FACEBOOK_APP_NAME = "Facebook";
    private final String FACEBOOK_SHA1 = "A0E980408030C669BCEB38FEFEC9527BE6C3DDD0".toLowerCase(Locale.ENGLISH);
    private final String FAKE_FACEBOOK = "Fake Facebook";
    // WhatsApp variables
    private final String WHATSAPP_APP_NAME = "WhatsApp";
    private final String WHATSAPP_SHA1 = "38A0F7D505FE18FEC64FBF343ECAAAF310DBD799".toLowerCase(Locale.ENGLISH);
    private final String FAKE_WHATSAPP = "Fake WhatsApp";
    // Instagram variables
    private final String INSTAGRAM_APP_NAME = "Instagram";
    private final String INSTAGRAM_SHA1 = "76D72C35164513A4A7EBA098ACCB2B22D2229CBE".toLowerCase(Locale.ENGLISH);
    private final String FAKE_INSTAGRAM = "Fake Instagram";
    // King games
    private final String KING_GAME_NAMES = "AlphaBetty Saga " +
            "Candy Crush Soda Saga " + "Candy Crush Saga " + "Farm Heroes Saga " +
            "Pet Rescue Saga " + "Bubble Witch 2 Saga " + "Scrubby Dubby Saga " +
            "Diamond Digger Saga " + "Papa Pear Saga " + "Pyramid Solitaire Saga " +
            "Bubble Witch Saga " + "King Challenge ";
    private final String KING_GAMES_SHA1 = "9E93B3336C767C3ABA6FCC4DEADA9F179EE4A05B";
    // Mine Craft
    private final String MINECRAFT_NAMES = "Minecraft: Pocket Edition " +
            "Minecraft - Pocket Edition";
    private final String MINECRAFT_PKG_NAME = "com.mojang.minecraftpe";

    private String m_appName, m_sha1, m_pkgName;

    public FakeApps(String m_appName, String m_sha1, String m_pkgName) {
        this.m_appName = m_appName;
        this.m_sha1 = m_sha1;
        this.m_pkgName = m_pkgName;
    }

    public String scanForFakeApps(){
        String result = "";

        if (m_appName.equals(getFACEBOOK_APP_NAME())
                && !(m_sha1.equals(getFACEBOOK_SHA1())))
            result += "-> "+getFAKE_FACEBOOK() + "\n";

        if (m_appName.equals(getWHATSAPP_APP_NAME())
                && !(m_sha1.equals(getWHATSAPP_SHA1())))
            result += "-> "+getFAKE_WHATSAPP() + "\n";

        if (m_appName.equals(getINSTAGRAM_APP_NAME())
                && !(m_sha1.equals(getINSTAGRAM_SHA1())))
            result += "-> "+getFAKE_INSTAGRAM() + "\n";

        if (KING_GAME_NAMES.contains(m_appName) && !(m_sha1.equals(KING_GAMES_SHA1)))
            result  += "-> Fake King Game\n";

        if (m_pkgName.equals("com.minitorrent.kimill"))
            result  += "-> Fake Market\n";

        if (MINECRAFT_NAMES.contains(m_appName) && !(m_sha1.equals(MINECRAFT_PKG_NAME)))
            result  += "-> Fake Mine craft\n";

        return result;
    }

    private String getFACEBOOK_APP_NAME() {
        return FACEBOOK_APP_NAME;
    }

    private String getFACEBOOK_SHA1() {
        return FACEBOOK_SHA1;
    }

    private String getFAKE_FACEBOOK() {
        return FAKE_FACEBOOK;
    }

    private String getWHATSAPP_APP_NAME() {
        return WHATSAPP_APP_NAME;
    }

    private String getWHATSAPP_SHA1() {
        return WHATSAPP_SHA1;
    }

    private String getFAKE_WHATSAPP() {
        return FAKE_WHATSAPP;
    }

    private String getINSTAGRAM_APP_NAME() {
        return INSTAGRAM_APP_NAME;
    }

    private String getINSTAGRAM_SHA1() {
        return INSTAGRAM_SHA1;
    }

    private String getFAKE_INSTAGRAM() {
        return FAKE_INSTAGRAM;
    }
}
