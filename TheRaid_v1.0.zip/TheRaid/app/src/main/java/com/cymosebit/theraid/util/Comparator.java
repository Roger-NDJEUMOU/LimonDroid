package com.cymosebit.theraid.util;

import com.cymosebit.theraid.models.AppEntry;

import java.text.Collator;

/**
 * Created by Roger NDJEUMOU on 09/05/2017.
 */

/**
 * Perform alphabetical comparison of application entry objects.
 * SOURCE : https://developer.android.com/reference/android/content/AsyncTaskLoader.html
 */
public class Comparator {
    public static final java.util.Comparator<AppEntry> ALPHA_COMPARATOR = new java.util.Comparator<AppEntry>() {
        private final Collator sCollator = Collator.getInstance();
        @Override
        public int compare(AppEntry object1, AppEntry object2) {
            return sCollator.compare(object1.getLabel(), object2.getLabel());
        }
    };
}
