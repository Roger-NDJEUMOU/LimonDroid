package com.cymosebit.theraid.models;

/**
 * Created by theraid on 1/13/18.
 */

public class Capability {
    String capability;
    boolean value;

    public Capability(String capability, boolean value) {
        this.capability = capability;
        this.value = value;
    }

    public String getCapability() {
        return capability;
    }

    public void setCapability(String capability) {
        this.capability = capability;
    }

    public boolean isValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }
}
