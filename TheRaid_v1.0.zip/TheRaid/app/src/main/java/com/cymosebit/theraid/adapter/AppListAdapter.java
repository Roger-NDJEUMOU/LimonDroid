package com.cymosebit.theraid.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cymosebit.theraid.R;
import com.cymosebit.theraid.activity.AnalysisReportActivity;
import com.cymosebit.theraid.models.AppEntry;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Roger NDJEUMOU on 09/05/2017.
 */

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.ViewHolder> {

    private final LayoutInflater inflater;
    private List<AppEntry> appList;
    private List<AppEntry> originalList;
    private AppFilter filter;
    private Context mContext;

    public AppListAdapter (Context context){
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mContext = context;
    }

    public void setData(List<AppEntry> data){
        this.appList = data;
        this.originalList = data;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.installed_app_item_list, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final AppEntry appEntry = appList.get(position);
        holder.appIcon.setImageDrawable(appEntry.getIcon());
        holder.appLabel.setText(appEntry.getLabel());
        holder.pkgName.setText(appEntry.getPackageName());
        holder.appSize.setText(appEntry.getAppSize());
        // adding click listener on card view to launch static analysis
        holder.appCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, AnalysisReportActivity.class);
                intent.putExtra(Intent.EXTRA_TEXT, appEntry.getLabel());
                intent.putExtra(Intent.EXTRA_SUBJECT, appEntry.getPackageName());
                mContext.startActivity(intent);
            }
        });
    }

    public AppFilter getFilter() {
        if (filter == null)
            filter = new AppFilter();
        return filter;
    }

    @Override
    public int getItemCount() {
        int size = 0;
        if (appList != null)
            size = appList.size();
        return size;
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        public CardView appCardView;
        public ImageView appIcon;
        public TextView appLabel;
        public TextView pkgName;
        public TextView appSize;

        public ViewHolder(View view){
            super(view);

            appCardView = (CardView) view.findViewById(R.id.installed_app_card_view);
            appIcon = (ImageView) view.findViewById(R.id.app_icon);
            appLabel = (TextView) view.findViewById(R.id.app_label);
            pkgName = (TextView) view.findViewById(R.id.package_name);
            appSize = (TextView) view.findViewById(R.id.app_size);
        }
    }

    public class AppFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            if (constraint != null && constraint.length() > 0){
                List<AppEntry> filterlist = new ArrayList<AppEntry>();
                for (int i = 0; i < originalList.size(); i++){
                    if ((originalList.get(i).getLabel().toUpperCase()
                    .contains(constraint.toString().toUpperCase()))){

                        filterlist.add(originalList.get(i));
                    }
                }
                results.count = filterlist.size();
                results.values = filterlist;
            } else {
                results.count = originalList.size();
                results.values = originalList;
            }

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            appList = (ArrayList<AppEntry>) results.values;
            notifyDataSetChanged();
        }
    }
}
