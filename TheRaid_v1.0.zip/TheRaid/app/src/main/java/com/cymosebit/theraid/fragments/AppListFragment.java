package com.cymosebit.theraid.fragments;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.cymosebit.theraid.R;
import com.cymosebit.theraid.adapter.AppListAdapter;
import com.cymosebit.theraid.models.AppEntry;
import com.cymosebit.theraid.models.AppListLoader;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class AppListFragment extends Fragment implements LoaderManager.LoaderCallbacks<List<AppEntry>> {

    RecyclerView recyclerView;
    EditText searchET;
    AppListAdapter mAdapter;
    ProgressDialog progressDialog;

    public AppListFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Show progress dialog
        progressDialog = ProgressDialog.show(getContext(),
                getString(R.string.loading_title), getString(R.string.loading_data));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_app_list, container, false);

        recyclerView = (RecyclerView) rootView.findViewById(R.id.installed_app_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        searchET = (EditText) rootView.findViewById(R.id.search_edit);
        searchET.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                mAdapter.getFilter().filter(s);
            }
        });

        mAdapter = new AppListAdapter(getContext());
        recyclerView.setAdapter(mAdapter);
        // Inflate the layout for this fragment
        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // Prepare the loader.  Either re-connect with an existing one,
        // or start a new one.
        getLoaderManager().initLoader(0, null, this);
    }

    @Override
    public Loader<List<AppEntry>> onCreateLoader(int id, Bundle args) {
        // This is called when a new Loader needs to be created.  This
        // sample only has one Loader with no arguments, so it is simple.
        return new AppListLoader(getActivity());
    }

    @Override
    public void onLoadFinished(Loader<List<AppEntry>> loader, List<AppEntry> data) {
        mAdapter.setData(data);
        progressDialog.dismiss();
    }

    @Override
    public void onLoaderReset(Loader<List<AppEntry>> loader) {
        mAdapter.setData(null);
    }
}
