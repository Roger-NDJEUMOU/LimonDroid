package com.cymosebit.theraid.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.cymosebit.theraid.R;
import com.cymosebit.theraid.models.Capability;
import com.cymosebit.theraid.models.FuzzyMatch;
import com.cymosebit.theraid.models.VirusTotalScanReport;
import com.cymosebit.theraid.util.CryptographicHash;
import com.cymosebit.theraid.util.FuzzyHash;
import com.cymosebit.theraid.util.SSDeep;
import com.cymosebit.theraid.yara_rules.FakeApps;
import com.cymosebit.theraid.yara_rules.MalwareCapabilities_1;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AnalysisReportActivity extends AppCompatActivity {
    static final double FUZZY_PERCENTAGE = 0.7;
    static final double VIRUSTOTAL_PERCENTAGE = 30;
    static final double VIRUSTOTAL_THRESHOLD = (0.5547699995 * VIRUSTOTAL_PERCENTAGE);

    static final int MALWARE_SAMPLE = 2572;
    static final String SSDEEP_FORMAT = "ssdeep,1.1--blocksize:hash:hash,filename";
    static final String MASTER_DIR_NAME = "TheRaid_reports";
    static final String MALWARE_SSDEEP_FILE_NAME = "malware_ssdeep.txt";
    static final String INSTALLED_APPS_SSDEEP_FILE_NAME = "installed_app_ssdeep.txt";
    static File MALWARE_SSDEEP, INSTALLED_APPS_SSDEEP;

    ProgressDialog progressDialog;

    ImageView appIconImageView, decisionIcon;
    TextView summaryTV, appNameTV;

    ExpandableListAdapter expListAdapter;
    ExpandableListView expListView;

    String m_appName, m_packageName;
    String[] m_appPermission;

    String fileType, fileSize, SHA1, SHA256, appFuzzyHash;

    long fuzzyTime, malCapTime, virusTotalTime;

    boolean internet = false;
    int numberOfMalwareCapabilities = 0, numberOfAnalyzedApps = 0;

    ArrayList<FuzzyMatch> malwareFuzzyMatches, installedAppFuzzyMatches;
    ArrayList<String> malwareCapabilities;
    VirusTotalScanReport virustotalReport;

    // Creating report directory
    public static File getReportDirectory(Context context) {
        return context.getDir(MASTER_DIR_NAME, MODE_PRIVATE);
    }

    private String getFileType(String fileUrl) {
        return MimeTypeMap.getFileExtensionFromUrl(fileUrl);
    }

    private String getFileSize(String filePath) {
        DecimalFormat df = new DecimalFormat("0.00");

        File file = new File(filePath);
        String fSize = " ( " + file.length() + " bytes )";
        float sizeKb = 1024.0f;
        float sizeMb = sizeKb * sizeKb;

        if (file.length() >= sizeMb)
            return df.format(file.length() / sizeMb) + " MB " + fSize;

        return df.format(file.length() / sizeKb) + " KB " + fSize;
    }

    private String[] getCryptographicHashes(String filePath) {

        File apkFile = new File(filePath);

        String[] cryptoHashes = new String[2];
        cryptoHashes[0] = bytesToHex(CryptographicHash.SHA1.checksum(apkFile))
                .toLowerCase(Locale.ENGLISH);
        cryptoHashes[1] = bytesToHex(CryptographicHash.SHA256.checksum(apkFile))
                .toLowerCase(Locale.ENGLISH);

        return cryptoHashes;
    }

    private String bytesToHex(byte[] bytes) {
        final char[] hexArray = {'0', '1', '2', '3', '4', '5', '6', '7', '8',
                '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        char[] hexChars = new char[bytes.length * 2];
        int v;
        for (int j = 0; j < bytes.length; j++) {
            v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    private String[] getAppPermissions(Context context, String packageName) {
        try {
            PackageInfo info = context.getPackageManager()
                    .getPackageInfo(packageName, PackageManager.GET_PERMISSIONS);
            return info.requestedPermissions;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("GET APP PERMISSIONS :", e.toString());
            return null;
        }
    }

    // Defining progress dialog properties
    private void initProgresDialog() {
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setCancelable(false);
        progressDialog.setIndeterminate(false);
        progressDialog.setMessage("Analysis in process...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setProgress(0);
        progressDialog.setMax(100);
    }

    private void createMalwareSSDeepFile() {

        MALWARE_SSDEEP = new File(getReportDirectory(this), MALWARE_SSDEEP_FILE_NAME);
        if (!MALWARE_SSDEEP.exists()) {
            try {
                int i=0;
                FileOutputStream fileOutputStream = new FileOutputStream(MALWARE_SSDEEP, true);
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(getResources().openRawResource(R.raw.malware_hashes)));
                String line;
                while ((line = reader.readLine()) != null) {
                    fileOutputStream.write(line.getBytes());
                    fileOutputStream.write("\n".getBytes());
                    i++;
                }

                reader.close();
                fileOutputStream.close();

            } catch (IOException e) {
                Log.e("CREATE MALWARE SSDEEP :", e.toString());
            }
        }

    }

    private void createInstalledAppsSSDeepFile(){
        INSTALLED_APPS_SSDEEP = new File(getReportDirectory(this), INSTALLED_APPS_SSDEEP_FILE_NAME);
        if (!INSTALLED_APPS_SSDEEP.exists()){
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(INSTALLED_APPS_SSDEEP, true);

                fileOutputStream.write(SSDEEP_FORMAT.getBytes());
                fileOutputStream.write("\n".getBytes());

                fileOutputStream.close();

            } catch (IOException e) {
                Log.e("CREATE INSTALL SSDEEP :", e.toString());
            }
        }
    }

    boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analysis_report);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        if (intent == null) {
            finish();
        }

        this.createMalwareSSDeepFile();
        this.createInstalledAppsSSDeepFile();

        // retreiving data from main activity
        m_appName = intent.getStringExtra(Intent.EXTRA_TEXT);
        m_packageName = intent.getStringExtra(Intent.EXTRA_SUBJECT);
        m_appPermission = getAppPermissions(this, m_packageName);

        // initialize app icon view
        appIconImageView = (ImageView) findViewById(R.id.stat_app_icon);
        decisionIcon = (ImageView) findViewById(R.id.stat_decision_icon);

        // initialize text views
        appNameTV = (TextView) findViewById(R.id.stat_app_label);
        summaryTV = (TextView) findViewById(R.id.summary_static_analysis);

        // initialize progress dialog
        progressDialog = new ProgressDialog(this);
        initProgresDialog();

        // initialize expandable list
        expListView = (ExpandableListView) findViewById(R.id.expandable_LV);

        // check network state
        internet = isNetworkAvailable();

        PackageManager pm = getPackageManager();
        try {
            ApplicationInfo appInfo = pm.getApplicationInfo(m_packageName,
                    PackageManager.GET_UNINSTALLED_PACKAGES);

            appNameTV.setText(m_appName);
            appIconImageView.setImageDrawable(appInfo.loadIcon(pm));
            fileType = getFileType(appInfo.sourceDir);
            fileSize = getFileSize(appInfo.sourceDir);

            String[] cryptoHashes = getCryptographicHashes(appInfo.sourceDir);
            SHA1 = cryptoHashes[0];
            SHA256 = cryptoHashes[1];

            String[] dataForAnalysis = new String[3];
            dataForAnalysis[0] = appInfo.sourceDir;

            new Analysis().execute(dataForAnalysis);


        } catch (PackageManager.NameNotFoundException e) {
            Log.e("PKG NAME NOT FOUND :", e.toString());
        }

    }

    class Analysis extends AsyncTask<String, Integer, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... analysisData) {
            int count = 0;
            String fileSourceDir = analysisData[0];
            String fuzzyHash;

            if (internet) {
                getVirusTotalScanReport(SHA256);
            } else {
                virustotalReport = new VirusTotalScanReport(-1, "No internet !");
            }

            count += 10;
            updateProgress(count - 10, count);

            long start = System.currentTimeMillis();

            if (alreadyAnalyzed())
                fuzzyHash = getFuzzyHashForAlreadyAnalyzedApp();
            else
                fuzzyHash = computeFuzzyHash(fileSourceDir);

            fuzzyTime = (System.currentTimeMillis() - start);

            count += 35;
            updateProgress(count - 35, count);

            start = System.currentTimeMillis();
            malwareFuzzyMatches = fuzzyHashCompare(MALWARE_SSDEEP, fuzzyHash, m_appName);
            installedAppFuzzyMatches = fuzzyHashCompare(INSTALLED_APPS_SSDEEP, fuzzyHash, m_appName);
            fuzzyTime += (System.currentTimeMillis() - start);

            count += 10;
            updateProgress(count - 10, count);

            start = System.currentTimeMillis();
            malwareCapabilities = getMalwareCapabilities(SHA1);
            malCapTime = (System.currentTimeMillis() - start);

            count += 40;
            updateProgress(count - 40, count);

            return fuzzyHash;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            appFuzzyHash = s;

            displayExpandableList();

            progressDialog.dismiss();
        }

        void updateProgress(final int min, final int max) {
            int i = min;
            while (i < max) {
                try {
                    Thread.sleep(100);
                    i += 2;
                    publishProgress(i);
                } catch (InterruptedException e) {
                    Log.e("UPDATE PROGRESS", e.toString());
                }
            }
        }

        void displayExpandableList() {

            String virustotalMsg = " Detections : 0";
            if ((virustotalReport != null) && (virustotalReport.getResponseCode() == 1)) {
                virustotalMsg = " Detections : " + virustotalReport.getPositives() + " / "
                        + virustotalReport.getTotal() + " - Time = "+virusTotalTime+" ms";
            }

            String featuresHeader = "Features";

            String fuzzyComparisonHeader1 = getString(R.string.ssdeep_comparison_with_malware)
                    + " Matches : " + malwareFuzzyMatches.size() + " / " + MALWARE_SAMPLE
                    + " - Time = "+fuzzyTime+" ms";
            String fuzzyComparisonHeader2 = getString(R.string.ssdeep_comparison_with_installed)
                    + " Matches : " + installedAppFuzzyMatches.size() + " / " + numberOfAnalyzedApps;
            String malCapHeader = getString(R.string.malware_capabilities) + " " + numberOfMalwareCapabilities
                    + " - Time = "+malCapTime+" ms";
            String virustotalHeader = getString(R.string.virustotal) + virustotalMsg;
            String permHeader = getString(R.string.permissions) + " Total : 0";
            if (m_appPermission != null) {
                permHeader = getString(R.string.permissions) + " Total : " + m_appPermission.length;
            }
            List<String> listDataHeader = new ArrayList<>();
            listDataHeader.add(featuresHeader);
            listDataHeader.add(fuzzyComparisonHeader1);
            listDataHeader.add(fuzzyComparisonHeader2);
            listDataHeader.add(malCapHeader);
            listDataHeader.add(virustotalHeader);
            listDataHeader.add(permHeader);

            List<String> featuresChild = new ArrayList<>();
            featuresChild.add("File Type : "+ fileType);
            featuresChild.add("File Size : "+ fileSize);
            featuresChild.add("SHA1 checksum : "+ SHA1);
            featuresChild.add("SHA256 checksum : "+ SHA256);
            featuresChild.add("Fuzzy hash : "+ appFuzzyHash);

            List<String> fuzzyComparisonChild1 = new ArrayList<>();
            if (malwareFuzzyMatches.size() == 0)
                fuzzyComparisonChild1.add("No matches !");
            else {
                int i = 1;
                for (FuzzyMatch match : malwareFuzzyMatches) {
                    fuzzyComparisonChild1.add((i) + " - " + match.getFileName() + " : " + match.getMatchScore() + "%");
                    i++;
                }
            }

            List<String> fuzzyComparisonChild2 = new ArrayList<>();
            if (installedAppFuzzyMatches.size() == 0)
                fuzzyComparisonChild2.add("No matches !");
            else {
                int i = 1;
                for (FuzzyMatch match : installedAppFuzzyMatches) {
                    fuzzyComparisonChild2.add((i) + " - " + match.getFileName() + " : " + match.getMatchScore() + "%");
                    i++;
                }
            }

            List<String> malCapChild = new ArrayList<>();
            if (malwareCapabilities.size() > 0) {
                malCapChild.addAll(malwareCapabilities);
            } else {
                malCapChild.add("No matches !");
            }

            List<String> virustotalChild = new ArrayList<>();
            if (virustotalReport != null) {
                if (virustotalReport.getResponseCode() == 1) {
                    virustotalChild.add("Scan date : " + virustotalReport.getScanDate());
                    virustotalChild.add("Message : " + virustotalReport.getVerboseMessage());
                    virustotalChild.add("Permanent link : " + virustotalReport.getPermanentLink());
                } else {
                    virustotalChild.add("Message : " + virustotalReport.getVerboseMessage());
                }
            } else {
                virustotalChild.add("Message : Request timeout !");
            }

            List<String> permChild = new ArrayList<>();
            if ((m_appPermission != null) && (m_appPermission.length > 0)) {
                for (String perm : m_appPermission) {
                    permChild.add(" -> " + perm);
                }
            } else {
                permChild.add("No permissions !");
            }

            HashMap<String, List<String>> listDataChild = new HashMap<>();
            listDataChild.put(listDataHeader.get(0), featuresChild);
            listDataChild.put(listDataHeader.get(1), fuzzyComparisonChild1);
            listDataChild.put(listDataHeader.get(2), fuzzyComparisonChild2);
            listDataChild.put(listDataHeader.get(3), malCapChild);
            listDataChild.put(listDataHeader.get(4), virustotalChild);
            listDataChild.put(listDataHeader.get(5), permChild);


            expListAdapter = new com.cymosebit.theraid.adapter.
                    ExpandableListAdapter(getApplicationContext(), listDataHeader, listDataChild);

            // setting list adapter
            expListView.setAdapter(expListAdapter);

            // Take decision
            staticAnalysisDecision();
        }

        void staticAnalysisDecision() {
            DecimalFormat df = new DecimalFormat("0.00");
            String decision = "", aux = "";

            double percentageSimilarity = computeTotalSimilarityScore();
            if (malwareFuzzyMatches.size() > 0)
                aux += "\n" + getString(R.string.percentage_similarity)
                    .replace("#", "" + (percentageSimilarity)+
                            "% with "+malwareFuzzyMatches.size());

            double decisionPercentage = percentageSimilarity * FUZZY_PERCENTAGE;

            double virusTotalPercentage = computeVirusTotalDetectionPercentage() * VIRUSTOTAL_PERCENTAGE;
            if (virusTotalPercentage >= VIRUSTOTAL_THRESHOLD){
                decisionPercentage += VIRUSTOTAL_PERCENTAGE;
                aux += "\n" + getString(R.string.vt_greater_than_threshold);
            }else {
                decisionPercentage += virusTotalPercentage;
                if ((virusTotalPercentage*100/30) > 0)
                    aux += "\n" + getString(R.string.virustotal_percentage)
                        .replace("#", df.format(virusTotalPercentage*100/30));
            }

            decisionPercentage = Double.parseDouble(df.format(decisionPercentage)
                    .replaceAll(",","."));

            if (numberOfMalwareCapabilities > 0 && virusTotalPercentage >= VIRUSTOTAL_THRESHOLD) {
                decision = getString(R.string.malicious)
                        .replace("#", ""+decisionPercentage) + aux;
            }
            else if (numberOfMalwareCapabilities > 0) {
               aux += "\n" + getString(R.string.has_malware_capabilities)
                        .replace("#", "" + numberOfMalwareCapabilities);

               decision = getString(R.string.malicious_due_to_mal_cap)
                       .replace("*", ""+numberOfMalwareCapabilities)
                       .replace("#", ""+decisionPercentage) + aux;
            } else if (virusTotalPercentage >= VIRUSTOTAL_THRESHOLD) {
                decision = getString(R.string.blacklisted_by_VT)
                        .replace("#", ""+decisionPercentage);
            } else {
                decision = getString(R.string.potentially_malicious)
                        .replace("#", ""+decisionPercentage) + aux;
            }

            if (!internet)
                decision += "\n"+ getString(R.string.no_internet);

            summaryTV.setText(decision);

            displayDecisionIcon(decisionPercentage);
        }

        void displayDecisionIcon(double percentage){
            if (percentage <= 20)
                decisionIcon.setImageDrawable(getDrawable(R.mipmap.minimal));

            if (percentage > 20 && percentage <= 40)
                decisionIcon.setImageDrawable(getDrawable(R.mipmap.low));

            if (percentage > 40 && percentage <= 60)
                decisionIcon.setImageDrawable(getDrawable(R.mipmap.dangerous));

            if (percentage > 60 && percentage <= 80)
                decisionIcon.setImageDrawable(getDrawable(R.mipmap.extreme));

            if (percentage > 80)
                decisionIcon.setImageDrawable(getDrawable(R.mipmap.catastrophic));
        }

        double computeTotalSimilarityScore(){
            int sum = 0;
            if (malwareFuzzyMatches.size() >0) {
                for (FuzzyMatch match : malwareFuzzyMatches)
                    sum += match.getMatchScore();

                DecimalFormat df = new DecimalFormat("0.00");
                return Double.parseDouble(df.format(sum / (double) malwareFuzzyMatches.size())
                        .replaceAll(",", "."));
            }

            return sum;
        }

        double computeVirusTotalDetectionPercentage(){
            if (virustotalReport != null && virustotalReport.getResponseCode() == 1 ){
                double positives = virustotalReport.getPositives();
                double total = virustotalReport.getTotal();

                DecimalFormat df = new DecimalFormat("0.0000");
                return Double.parseDouble(df.format(positives/total)
                        .replaceAll(",","."));
            }

            return 0;
        }

        boolean alreadyAnalyzed() {
            String line;
            try {
                FileInputStream fileInputStream = new FileInputStream(INSTALLED_APPS_SSDEEP);
                BufferedReader bufferedReader = new BufferedReader(
                        new InputStreamReader(fileInputStream));
                while ((line = bufferedReader.readLine()) != null) {
                    String[] results = line.split(",");
                    if (m_appName.equals(results[1].replaceAll("\"", ""))) {
                        return true;
                    }
                }

                fileInputStream.close();

                return false;

            } catch (Exception e) {
                Log.e("ALREADY ANALYZED :", e.toString());
                return false;
            }
        }

        String getFuzzyHashForAlreadyAnalyzedApp() {
            String hash = null, line;
            FileInputStream fileInputStream;
            try {
                fileInputStream = new FileInputStream(INSTALLED_APPS_SSDEEP);
                BufferedReader bufferedReader = new BufferedReader(
                        new InputStreamReader(fileInputStream));
                while ((line = bufferedReader.readLine()) != null) {
                    String[] results = line.split(",");
                    if (m_appName.equals(results[1].replaceAll("\"", ""))) {
                        hash = results[0];
                    }
                }

                bufferedReader.close();
                fileInputStream.close();
            } catch (IOException e) {
                Log.e("GET FUZZY FOR ANALYZED:", e.toString());
            }

            return hash;
        }

        String computeFuzzyHash(String filePath) {
            String hash = null;
            File file = new File(filePath);
            SSDeep ssDeep = new SSDeep();

            try {
                FuzzyHash fuzzyHash = ssDeep.fuzzyHashFile(file, m_appName);
                hash = fuzzyHash.getBlocksize() + ":" + fuzzyHash.getHash() + ":" + fuzzyHash.getHash2();

                saveFuzzyHashToInstalledSSDeepFile(fuzzyHash.toString());

            } catch (IOException e) {
                Log.e("COMPUTE FUZZY HASH :", e.toString());
            }

            return hash;
        }

        void saveFuzzyHashToInstalledSSDeepFile(String fuzzyHash) {
            try {
                FileOutputStream outputStream = new FileOutputStream(INSTALLED_APPS_SSDEEP, true);
                outputStream.write(fuzzyHash.getBytes());
                outputStream.write("\n".getBytes());
                outputStream.close();

            } catch (Exception e) {
                Log.e("SAVE TO INSTALLED : ", e.toString());
            }
        }

        ArrayList<FuzzyMatch> fuzzyHashCompare(File inputFile, String fileHash, String fileName) {
            ArrayList<FuzzyMatch> fuzzyMatches = new ArrayList<>();
            String line;
            try {
                int i=0;
                FileInputStream fileInputStream = new FileInputStream(inputFile);
                BufferedReader bufferedReader = new BufferedReader(
                        new InputStreamReader(fileInputStream));
                while ((line = bufferedReader.readLine()) != null) {
                    String[] results = line.split(",");
                    String hashFromMasterFile = results[0];
                    String fileNameFromMasterFile = results[1].replaceAll(".apk","");
                    if (!fileNameFromMasterFile.equals(fileName)) {
                        int matchScore = FuzzyHash.compare(fileHash, hashFromMasterFile);
                        if (matchScore > 0) {
                            FuzzyMatch fuzzyMatch = new FuzzyMatch(fileNameFromMasterFile, matchScore);
                            fuzzyMatches.add(fuzzyMatch);
                        }
                    }
                    i++;
                }

                fileInputStream.close();

                if (inputFile.equals(INSTALLED_APPS_SSDEEP))
                    numberOfAnalyzedApps = (i-1);

            } catch (Exception e) {
                Log.e("FUZZY HASH COMPARISON :", e.toString());
            }

            return fuzzyMatches;
        }

        ArrayList<String> getMalwareCapabilities(String m_sha1) {
            ArrayList<String> malCapList = new ArrayList<>();

            FakeApps fakeApps = new FakeApps(m_appName, m_sha1, m_packageName);
            String listOfFakeApps = fakeApps.scanForFakeApps();
            if (listOfFakeApps.length() != 0) {
                malCapList.add(listOfFakeApps);
                numberOfMalwareCapabilities++;
            }

            MalwareCapabilities_1 malCap = new MalwareCapabilities_1(m_appName, m_packageName,
                    m_sha1, getBaseContext());
            ArrayList<Capability> capabilities1 = malCap.getM_capabilities();
            if (capabilities1.size() > 0) {
                for (Capability cap : capabilities1) {
                    malCapList.add("-> " + cap.getCapability());
                    numberOfMalwareCapabilities++;
                }
            } else {
                if (listOfFakeApps.length() != 0)
                    malCapList.add("-> No other malware capabilities !");
                else
                    malCapList.add("-> No malware capabilities !");
            }

            return malCapList;
        }

        void getVirusTotalScanReport(String sha256) {
            final String REPORT_URL = "https://www.virustotal.com/vtapi/v2/file/report";
            final String API_KEY = "api_key";
            final String RESOURCE = "resource";
            final String RESOURCE_VALUE = sha256;
            final String API_KEY_VALUE = "a916d07e8123497ac6f7c9e4fbd6f9dfb3e6fefc2aacdb2bbccd91964643790c";

            virusTotalTime = System.currentTimeMillis();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, REPORT_URL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                processJSON(jsonObject);
                            } catch (JSONException e) {
                                Log.e("GET VIRUSTOTAL REPORT :", "Error decoding JSON: " + e);
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e("VIRUSTOTAL CONNECTION :", error.toString());
                        }
                    }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<>();
                    headers.put(API_KEY, API_KEY_VALUE);
                    headers.put(RESOURCE, RESOURCE_VALUE);
                    return headers;
                }

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put(API_KEY, API_KEY_VALUE);
                    params.put(RESOURCE, RESOURCE_VALUE);
                    return params;
                }
            };

            //creating a request queue
            RequestQueue requestQueue = Volley.newRequestQueue(getBaseContext());

            //adding the string request to request queue
            requestQueue.add(stringRequest);

        }

        void processJSON(JSONObject jsonObject) {
            virusTotalTime = System.currentTimeMillis() - virusTotalTime;
            String scanDate, verboseMessage, permanentLink;
            int respCode, total, positives;
            try {
                respCode = jsonObject.getInt("response_code");
                switch (respCode) {
                    case 1: // got a positive result from virusTotal
                        total = jsonObject.getInt("total");
                        positives = jsonObject.getInt("positives");
                        scanDate = jsonObject.getString("scan_date");
                        verboseMessage = jsonObject.getString("verbose_msg");
                        permanentLink = jsonObject.getString("permalink");

                        virustotalReport = new VirusTotalScanReport(respCode, total, positives,
                                scanDate, verboseMessage, permanentLink);
                        break;

                    case 0: // No positive result
                        verboseMessage = jsonObject.getString("verbose_msg");
                        virustotalReport = new VirusTotalScanReport(respCode, verboseMessage);
                        break;

                    default:
                        verboseMessage = "Something went wrong while retrieving the scan report !";
                        virustotalReport = new VirusTotalScanReport(respCode, verboseMessage);

                }

            } catch (JSONException e) {
                Log.e("PROCESS JSON :", "Error decoding JSON: " + e);
            }

        }

    }

}