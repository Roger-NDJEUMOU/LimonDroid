package com.cymosebit.theraid.yara_rules;

import android.app.ApplicationErrorReport;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by theraid on 11/16/17.
 * Source: https://github.com/Yara-Rules/rules/blob/master/Mobile_Malware/Android_BatteryBot_ClickFraud.yar
 */

public class BatteryBot {
    // final String BOT_NAME = "BatteryBot";
    private final String BOT_SHA1 = "e1f9a573e1ce1f70829d41cbc6f0d8fb7b5b74f7";
    private final String BOT_PACKAGE_NAME = "com.polaris.BatteryIndicatorPro";
    private final String BOT_ACTIVITY = ".BatteryInfoActivity";
    private final String BOT_PERMISSION = "android.permission.SEND_SMS";

    private String m_sha1, m_package_name;
    private Context m_context;
    private String[] m_appPermissions;

    public BatteryBot(String m_package_name, String m_sha1,
                      String[] m_appPermissions, Context m_context) {
        this.m_package_name = m_package_name;
        this.m_sha1 = m_sha1;
        this.m_appPermissions = m_appPermissions;
        this.m_context = m_context;
    }

    public boolean isBatteryBot(){
        if ((hasBotActivity() && hasBotPermission()) || BOT_SHA1.equals(m_sha1))
            return true;

        return false;
    }

    private boolean hasBotPermission(){
        for (String p : m_appPermissions){
            if (p.equals(BOT_PERMISSION))
                return true;
        }

        return false;
    }

    private boolean hasBotActivity(){
        if (BOT_PACKAGE_NAME.contains(m_package_name))
            return true;

        Log.d("APP PACKEGE NAME :", m_package_name);
        Log.d("BOT PACKEGE NAME :", BOT_PACKAGE_NAME);

        return false;
    }
}
