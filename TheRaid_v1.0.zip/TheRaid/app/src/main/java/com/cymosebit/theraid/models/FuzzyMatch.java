package com.cymosebit.theraid.models;

/**
 * Created by theraid on 10/28/17.
 */

public class FuzzyMatch {
    String fileName;
    int matchScore;

    public FuzzyMatch(String fileName, int matchScore) {
        this.fileName = fileName;
        this.matchScore = matchScore;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getMatchScore() {
        return matchScore;
    }

    public void setMatchScore(int matchScore) {
        this.matchScore = matchScore;
    }
}
