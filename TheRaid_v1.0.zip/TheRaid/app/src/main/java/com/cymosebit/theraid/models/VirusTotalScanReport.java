package com.cymosebit.theraid.models;

/**
 * Created by theraid on 11/22/17.
 */

public class VirusTotalScanReport {
    int responseCode, total, positives;
    String scanDate, verboseMessage, permanentLink;

    public VirusTotalScanReport(int responseCode, int total, int positives,
                                String scanDate, String verboseMessage, String permanentLink) {
        this.responseCode = responseCode;
        this.total = total;
        this.positives = positives;
        this.scanDate = scanDate;
        this.verboseMessage = verboseMessage;
        this.permanentLink = permanentLink;
    }

    public VirusTotalScanReport(int responseCode, String verboseMessage) {
        this.responseCode = responseCode;
        this.total = 0;
        this.positives = 0;
        this.scanDate = null;
        this.verboseMessage = verboseMessage;
        this.permanentLink = null;
    }

    public int getResponseCode() {
        return responseCode;
    }

    public int getTotal() {
        return total;
    }

    public int getPositives() {
        return positives;
    }

    public String getScanDate() {
        return scanDate;
    }

    public String getVerboseMessage() {
        return verboseMessage;
    }

    public String getPermanentLink() {
        return permanentLink;
    }
}
