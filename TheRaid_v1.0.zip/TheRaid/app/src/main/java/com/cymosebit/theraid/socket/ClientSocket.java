package com.cymosebit.theraid.socket;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;

import java.io.*;
import java.net.*;

/**
 * Created by theraid on 12/18/17.
 */

public class ClientSocket {
    private static final String SERVER_IP = "10.42.0.1";//"192.168.8.102";
    private static final int SERVER_PORT = 1217;
    private static final int MAX_SIZE = 20*1024*1024;
    private static final String TAG = "CLIENT SOCKET:";

    public ClientSocket(final Activity activity, String apkSourceDir, String appName,
                        String packageName) {
        final File apkFile = new File(apkSourceDir);
        // Get file size
        final int apkSize = (int) apkFile.length();
        if (apkSize >= MAX_SIZE){
            Toast.makeText(activity,"File is too large!", Toast.LENGTH_LONG).show();
        } else {
            final String appAndPackageName = appName.replaceAll("\\s","")+".apk;"+packageName;

            new Thread(new Runnable() {
                @Override
                public void run() {
                    Socket client = null;
                    try{
                        //Toast.makeText(activity,"Connecting to "+SERVER_IP+" on port "+SERVER_PORT, Toast.LENGTH_SHORT).show();
                        Log.d(TAG,"Connecting to "+SERVER_IP+" on port "+SERVER_PORT);
                        client = new Socket(SERVER_IP,SERVER_PORT);

                        String serverName = client.getInetAddress().getHostName();
                        Log.d(TAG,"Connected to "+serverName);
                        //Toast.makeText(activity, "Connected to "+serverName,Toast.LENGTH_SHORT).show();

                        // Sending package name, app name and size
                        OutputStream outToServer1 = client.getOutputStream();
                        DataOutputStream output = new DataOutputStream(outToServer1);
                        output.writeInt(apkSize);
                        output.writeUTF(appAndPackageName);

                        // Getting acknowledge message
                        InputStream inputFromServer = client.getInputStream();
                        DataInputStream inServer = new DataInputStream(inputFromServer);
                        Log.d(TAG, "FROM SERVER - "+inServer.readUTF());

                        // Sending apk file
                        byte[] bytesArray = new byte[apkSize];
                        InputStream inputFile = new FileInputStream(apkFile);
                        OutputStream outToServer2 = client.getOutputStream();

                        int count;
                        while ( (count = inputFile.read(bytesArray) ) > 0 ){
                            outToServer2.write(bytesArray,0,count);
                        }

                        outToServer2.close();
                        inputFile.close();
                        client.close();
                    } catch(IOException exception){
                        Log.e(TAG,exception.toString());
                        //Toast.makeText(activity,"Error connecting to "+SERVER_IP,Toast.LENGTH_LONG).show();
                    }

                }
            }).start();

        }

    }

}
